""" Programa Adulto
Descrição: Esse programa tem por objetivo analisar a sua idade e definir se o usuário é adulto.
Versão: 0.0.1
Data:24/03/2026
Autor: Arthur P. Bitencourt

"""
# Alocação de Memória
idade=0
texto = " "
# Entrada de Dados
idade = int(input("\nQual é a sua idade?" ))
# Processamento de Dados
if idade>=18:
    texto = "Tu é adulto!"
else:
    texto = "Tu é de menor!"
# Saída de Dados
print(texto)