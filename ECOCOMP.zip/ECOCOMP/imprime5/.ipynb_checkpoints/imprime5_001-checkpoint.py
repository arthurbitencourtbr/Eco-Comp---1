"""
Programa imprime5
Descrição: Esta programa imprime na tela os 5 primeiros números na tela.
Autor: Arthur P. Bitencourt
Data: 24/03/2026
Versão: 0.0.1
"""

# Alocação de Memória
numero_1=0
numero_2=0
numero_3=0
numero_4=0
numero_5=0
i=0

# Entrada de Dados

# Processamento da Dados

# Saída de Dados
while i < 5:
    print(i+1)
    i = i+1