"""
Programa imprime5
Descrição: Esta programa imprime na tela os 5 primeiros números na tela. Esta versão elimina alocação desnecessária de memória.
Autor: Arthur P. Bitencourt
Data: 24/03/2026
Versão: 0.1.0
"""

# Alocação de Memória
i=0

# Entrada de Dados

# Processamento da Dados

# Saída de Dados
while i < 5:
    print(i+1)
    i = i+1